<?php
/*
Plugin Name: PledgeBank.com
Plugin URI: http://www.memespring.co.uk
Description: 1) Displays current pledges from PledgeBank.com using keywords; 2)Displays a random pledge based on keywords; 3) Displays a form for creating new pledges on PledgeBank.com 

Originaly built for LoveMusicHateRacism.com. The RSS components are based on flickrRSS by Dave Kellam.
 
Version: 1.0
License: GPL
Author: Richard Pope - mySociety volunteer
Author URI:http://www.memespring.co.uk
*/


if (is_plugin_page()) { 
	
	//Saving etc
	 if (isset($_POST['save_pledgebank_settings'])) {
       $option_keywords = $_POST['keywords'];
       $option_format = $_POST['format'];
       $option_limit = $_POST['limit'];
       $option_defaultpledgetext = $_POST['defaultpledgetext'];
       $option_defaultpledgetarget = $_POST['defaultpledgetarget'];
       $option_defaultpledgeinstructions = $_POST['defaultpledgeinstructions'];
       update_option('pledgebank_keywords', $option_keywords);
       update_option('pledgebank_format', $option_format);
       update_option('pledgebank_limit', $option_limit);
       update_option('pledgebank_default_pledge_text', $option_defaultpledgetext);
       update_option('pledgebank_default_pledge_target', $option_defaultpledgetarget);
       update_option('pledgebank_default_pledge_instructions', $option_defaultpledgeinstructions);
       ?> <div class="updated"><p>All saved : )</p></div> <?php
     }
	
	?> 
    <div class="wrap" style="position:relative;">   
    <p style="text-align:right; position:absolute; right:1em; top:1px;"><a href="http://www.mysociety.org"  style="border:none!important;"><img src="http://www.placeopedia.com/images/mysociety.png" alt="mySociety" /></a></p>
    <h2>Pledgebank.com</h2>
    
	<form method="post">
          
            <fieldset class="options">
            	<h3>Display options</h3>
            	<table>
            		<tr>
            			<td>
            				<label for="keywords">Display pledges for </label>
            			</td>
            			<td>
            				<input name="keywords" type="text" id="keywords" value="<?php echo get_option('pledgebank_keywords'); ?>" size="30" /> 
    						<em>enter a town or keyword. e.g. <strong>London</strong> or <strong>Environment</strong></em>
            			</td>
            		</tr>
            		<tr>
            			<td>
            				<label for="keywords">Format</label>
            			</td>
            			<td>
	            			<select id="format" name="format">
		    					<option <?php if(get_option('pledgebank_format') == 'title') { echo 'selected="selected"'; } ?> value="title">Pledge title</option>
		    					<option <?php if(get_option('pledgebank_format') == 'description') { echo 'selected="selected"'; } ?> value="description">Pledge description</option>
		    				</select>
            			</td>
            		</tr>
            		<tr>
            			<td>
            				<label for="keywords">Limit the length of the pledges in lists to </label>
            			</td>
            			<td>
            				<input name="limit" type="text" id="limit" value="<?php if (get_option('pledgebank_limit')) echo get_option('pledgebank_limit'); else echo '100'  ?>" size="5" /> 
    						<em>Longer pledges will be replaced with '...'.</em>
            			</td>
            		</tr>
            	</table>
            </fieldset>
            <br/>
            <br/>
            <fieldset>
            	<h3>Pledge creation options</h3>
            	<table>
            		<tr>
            			<td>
            				<label for="defaultpledgetext">Default pledge text </label>
            			</td>
            			<td>
            				<textarea name="defaultpledgetext" type="text" id="defaultpledgetext" cols="40"><?php if (get_option('pledgebank_default_pledge_text')){
										 echo get_option('pledgebank_default_pledge_text');
								}else{
									echo 'Organise a Love Music Hate Racism Event in [YOUR TOWN]';
								}
								 ?>
            				</textarea> 
            			</td>
            		</tr>
            		<tr>
            			<td>
            				<label for="defaultpledgetarget">Default pledge target </label>
            			</td>
            			<td>
            				<input name="defaultpledgetarget" type="text" id="defaultpledgetarget" value="<?php if (get_option('pledgebank_default_pledge_target')) echo get_option('pledgebank_default_pledge_target'); else echo '10'  ?>" size="5" />
            			</td>
            		</tr>
            		<tr>
            			<td>
            				<label for="defaultpledgeinstructions">Default pledge instructions </label>
            			</td>
            			<td>
            				<input name="defaultpledgeinstructions" type="text" id="defaultpledgeinstructions" size="40" value="<?php if (get_option('pledgebank_default_pledge_instructions')) echo get_option('pledgebank_default_pledge_instructions'); else echo 'help out / turn up / buy a ticket'  ?>" size="5" />
            			</td>
            		</tr>
            	</table>
            </fieldset>
     		
	  <div class="submit"> 
            <input type="submit" name="save_pledgebank_settings" value="<?php _e('Save', 'save_pledgebank_settings') ?>" style="font-weight:bold;" /></div>
    </p></form>
    
    <h3>Techy instructions</h3>
    <h4>1) How to display a list of pledges</h4>
    <p>Just add the following to one of your templates (e.g. sidebar.php):</p>
    <code>
    	&lt;?php get_PledgeBank(); ?&gt;
    </code>
    <p>You can control how the pledges appear using these parameters:</p>
    <code>
    	get_PledgeBank($num_items, $show_title, $title_text)<br/><br/>
    	<strong>$num_items</strong> is the number of items to display (defaults to 5)<br/><br/>
    	<strong>$show_title</strong> display a title above the pledges (defaults to true)<br/><br/>
    	<strong>$title_text</strong> override the default title (defaults to '')<br/><br/>
    </code>
    <h4>2) How to display a random pledge from your list</h4>
    <p>Add the following to one of your templates</p>
    <code>&lt;?php get_random_pledge(); ?&gt;</code>
     <p>You can control how the pledge is displayed using the following parameters</p>
     <code>
     	get_random_pledge ($html_before, $html_after)<br/><br/>
     	<strong>$html_before</strong> is the html tag to include before the pledge (the default is &lt;blockquote&gt;)<br/><br/>
     	<strong>$html_after</strong> is the html tag to include after the pledge (the default is &lt;/blockquote&gt;)<br/><br/>
    </code>
    <h4>3) Adding a pledge form to your website</h4>
    <p>Add the following to one of your templates</p>
    <code>&lt;?php getPledgeForm(); ?&gt;</code>
    
</div>
<?php }else{

	//List Pledges
	function get_PledgeBank($num_items = 5, $show_title = true, $title_text = '') {
		
		//get the settings
		$settings_keywords = trim(get_option('pledgebank_keywords'));
		$settings_format = trim(get_option('pledgebank_format'));
		
		//check the rss readwer is installed
		if (!function_exists('MagpieRSS')) {
			require_once (ABSPATH . WPINC . '/rss-functions.php');
			error_reporting(E_ERROR);
		}

		//Print the title
		if($show_title){
			if ($title_text!=''){
				print '<h4>' . $title_text . '</h4>';
			}else{
				print '<h4>Pledgebank.com pledges about ' . $settings_keywords . '</h4>';	
			}
		}
	
	// get the rss file
	$rss_url = getRssUrl($settings_keywords);
	$rss = @ fetch_rss($rss_url);
	
		if ($rss) {
		    $itemurl = "";
		    // number of items
			$items = array_slice($rss->items, 0, $num_items);
		
		    //dont really need to use regex here, but might be usefull to leave it in for later
		    //e.g. if extra info was embedded in the description (postcode,town etc)
		    $itemUrlMatches = array();
		    foreach ( $items as $item ) {
		     if(preg_match('(.*)', $item['title'],$itemUrlMatches)) {
		
		           $itemurl = $itemUrlMatches[1];
		 
		           $title = htmlspecialchars(stripslashes($item['title']));
		           $description = htmlspecialchars(stripslashes($item['description']));
		           $description = substr($description,0,100) . '...';
		           $url = $item['link'];
			
		        //output
		        $display_text = '';
		        if ($settings_format == 'description'){
		        	$display_text = $description;
		        }else{
		        	$display_text = $title;
		        }
		        print '<li>' . "<a href=\"$url\" title=\"View Pledge\">$display_text</a>" . '</li>' ;      
		       } 
		    }
		} 	
	
	}
	
	//Random Pledge
	function get_random_pledge ($html_before = '<blockquote>', $html_after = '</blockquote>'){
		//get the settings
		$settings_keywords = trim(get_option('pledgebank_keywords'));
		$settings_format = trim(get_option('pledgebank_format'));
		
		// get the rss file
		$rss_url = getRssUrl($settings_keywords);
		$rss = @ fetch_rss($rss_url);
		
			if ($rss) {
			
			    $number_of_items = sizeOf($rss->items);
			    $random = (rand()%$number_of_items);
			
				$items = array_slice($rss->items, $random, 1);
			
				$itemUrlMatches = array();
			    foreach ( $items as $item ) {
			     if(preg_match('(.*)', $item['title'],$itemUrlMatches)) {
					
			           $itemurl = $itemUrlMatches[1];
			 
			           $title = htmlspecialchars(stripslashes($item['title']));
			           $description = htmlspecialchars(stripslashes($item['description']));
			           $url = $item['link'];
				
			        //output
			        $display_text = '';
			        if ($settings_format == 'description'){
			        	$display_text = $description;
			        }else{
			        	$display_text = $title;
			        }
			        
			        print $html_before . $display_text 
						. '<br/><br/><a href=\"$url\" title=\"View Pledge\">Sign this pledge</a>' 
						. $html_after;      
			       } 
			    }
			} 	
	}
	
	//Create Pledge form
	
	function getPledgeForm (){
		
		//get the settings
		$settings_text = trim(get_option('pledgebank_default_pledge_text'));
		$settings_target = trim(get_option('pledgebank_default_pledge_target'));
		$settings_instructions = trim(get_option('pledgebank_default_pledge_instructions'));
		
		// build up the form
		$form_text = '';	
		$form_text .= '<form accept-charset="utf-8" name="pledge" method="post" action="http://www.pledgebank.com/new">';
		$form_text .= '<table  style="padding:none; margin:none;">';
		$form_text .= '<tr><td>';
		$form_text .= '<label for="title"><strong>I will</strong></label><br/>';
		$form_text .= '<textarea title="Pledge" name="title" id="txtTitle"rows="3" cols="40">' . $settings_text .'</textarea>';
		$form_text .= '</td></tr>';
		$form_text .= '<tr><td>';
		$form_text .= '<label for="target"><strong>but only if</strong>&nbsp;&nbsp;</label>';
		$form_text .= '<input title="Target number of people" size="5" type="text" id="txtTarget" name="target" value="' . $settings_target . '">';
		$form_text .= '<input type="hidden" id="hidType" name="type" value="other people">';
		$form_text .= '<strong>&nbsp;other people</strong>';
		$form_text .= '</td></tr>';
		$form_text .= '<tr><td>';
		$form_text .= '<label for="signup"><strong>will</strong>&nbsp;&nbsp;</label>';
		$form_text .= '<input type="text" id="txtSignup" name="signup" size="40" value="' . $settings_instructions . '">';
		$form_text .= '<input type="hidden" name="date" value="">';
		$form_text .= '<input type="hidden" name="ref" value=""> ';
		$form_text .= '<input type="hidden" name="detail" value="" />';
		$form_text .= '<input type="hidden" name="name" value="">';
		$form_text .= '<input type="hidden" name="email" value="">';
		$form_text .= '<input type="hidden" name="identity" value="">';
		$form_text .= '</td></tr>';
		$form_text .= '</table>';
		$form_text .= '<br/>';
		$form_text .= '<input id="btnPledgeContinue" class="button" type="submit" name="tostep1" value="Continue on Pledgebank.com &gt;&gt;">';
		$form_text .= '</form>';
		
		//Print the form
		print $form_text;
		
	} 
	
	//Suport functions
	function getRssUrl($keywords = ''){
		
		$rss_url = '';
		
		//build up the url
		$rss_url = 'http://gb.en-gb.pledgebank.com/rss/search?q=' . urlencode($keywords);
		
		return $rss_url; 
	}
	
	//Menus etc
	function pb_admin_menu() {
	    $pagefile = basename(__FILE__);
	        add_options_page('PledgeBank Options Page', 'PledgeBank.com', 8, $pagefile);
	        }
	        
	add_action('admin_menu', 'pb_admin_menu');
}


?>