<?php
/*
Plugin Name: PledgeBank widget
Description: Adds a sidebar widget to display a pledge's progress.
Author: mySociety <http://www.mysociety.org/>
Version: 1.0
Author URI: http://www.pledgebank.com/

TODO: Simply prints the JS include, could use server code instead. i18n.
*/

function widget_pledgebank_init() {
	if ( !function_exists('register_sidebar_widget') )
		return;

	function widget_pledgebank($args) {
		extract($args);
		$options = get_option('widget_pledgebank');
		$ref = $options['ref'];
		$title = $options['title'];
		echo $before_widget . $before_title . $title . $after_title;
		$js_url = 'http://www.pledgebank.com/' . urlencode($ref) . '/progress.js';
		echo '<script type="text/javascript" src="' . $js_url . '"></script>';
		echo $after_widget;
	}

	function widget_pledgebank_control() {
		$options = get_option('widget_pledgebank');
		if ( !is_array($options) )
			$options = array('title'=>'', 'ref'=>'');
		if ( $_POST['pledgebank-submit'] ) {
			$options['title'] = strip_tags(stripslashes($_POST['pledgebank-title']));
			$options['ref'] = strip_tags(stripslashes($_POST['pledgebank-ref']));
			$options['ref'] = preg_replace('#http://[^/]*?\.pledgebank\.com/#', '', $options['ref']);
			update_option('widget_pledgebank', $options);
		}

		$title = htmlspecialchars($options['title'], ENT_QUOTES);
		$ref = htmlspecialchars($options['ref'], ENT_QUOTES);
?>		
<div style="text-align:right">
<p><label for="pledgebank-title">Title: <input id="pledgebank-title" name="pledgebank-title" type="text" value="<?=$title?>" /></label></p>
<p><label for="pledgebank-ref">PledgeBank reference/URL: <input id="pledgebank-ref" name="pledgebank-ref" type="text" value="<?=$ref?>" /></label></p>
<input type="hidden" id="pledgebank-submit" name="pledgebank-submit" value="1" />
</div>
<?
	}
	
	register_sidebar_widget(array('PledgeBank', 'widgets'), 'widget_pledgebank');
	register_widget_control(array('PledgeBank', 'widgets'), 'widget_pledgebank_control', 300, 100);
}

add_action('widgets_init', 'widget_pledgebank_init');

?>