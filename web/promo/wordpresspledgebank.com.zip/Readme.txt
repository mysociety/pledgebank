Hi,

All yopu need to do to use this plugin is

1) Add PledgeBank.com.php to your plugins folder

2) Enable it 

3) Go to Options > PledgeBank.com to configure it

There are instructions on the configuration page on how to use the plugin with your templates.